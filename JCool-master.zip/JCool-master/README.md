This repository is unmaintained
===============================

This was a project which aimed to create visually striking Java Swing components for building rich user interfaces, but it's no longer mantained. It's unfinished and should not be used in production as is. However, some ideas could be taken from the code and some components are quite stable and could be reused.

As it attracted some attention in [`this`][vid1] [`videos`][vid2] and I've received many mails of people asking for the demo code I used in them, I've [`uploaded it here`][demoCode]. Please, be aware that it's code I wrote 4 years ago for testing purposes and not thought to be published, so it sucks... but it could useful for someone. It contains Netbeans project files also. Use it with caution!

[vid1]:https://www.youtube.com/watch?v=6wiCcA3eydU
[vid2]:https://www.youtube.com/watch?v=hWwNR-Y-LtA
[demoCode]:https://mega.nz/#!vVxjxY5C!9e-jD5nqKAQLsGrHKUoubyWnjr0mYwB3fdqb51M0YKA